<form action="action.php" method="post">
    Nom:<input type="text" name="nom" /><br>
    <input type="submit" value="Envoyer">
</form>


<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <link href="styles.css">
    <title>PAGE LOGIN</title>
</head>

<body>
    </head>













</body>

</html>